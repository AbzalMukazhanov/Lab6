function clearDisplay() {
    document.getElementById('display').value = '';
}

function inputValue(value) {
    document.getElementById('display').value += value;
}

function calculate() {
    try {
        let display = document.getElementById('display');
        let result = eval(display.value);
        display.value = result;
    } catch (e) {
        alert('Error');
    }
}